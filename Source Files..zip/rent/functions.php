<?php

include("registration/db_connect.php");

function getEstateAgents(){
global $conn;
    $result = $conn->query("SELECT * FROM `estate_agent` JOIN accommodation ON estate_agent.estate_agent_id = 
                            accommodation.accommodation_estate_agent GROUP BY estate_agent_name");


         while($row = $result -> fetch_assoc()) {
                    $estate_agent_id = $row['estate_agent_id'];
                    $estate_agent_name = $row['estate_agent_name'];
                    
                    echo "<dd> <a href = 'index.php?accommodation_estate_agent=$estate_agent_id'> $estate_agent_name</a> </dd>";
                    }
                }

function getAccommodationTypeID(){
global $conn;
    $result = $conn->query("SELECT * FROM accommodation_type JOIN accommodation ON accommodation_type.accommodation_type_id = 
                            accommodation.accommodation_type GROUP BY accommodation_type.description");


         while($row = $result -> fetch_assoc()) {
                    $accommodation_type_id = $row['accommodation_type_id'];
                    $description = $row['description'];
                    
                    echo "<dd> <a href = 'index.php?accommodation_type=$accommodation_type_id'> $description</a> </dd>";
                    }
                }


function getAllAccommodations(){
    if(!isset($_GET['accommodation_estate_agent']) && !isset($_GET['accommodation_type'])){
    global $conn;
    $result = $conn->query("SELECT * From accommodation Left Join estate_agent On accommodation.accommodation_estate_agent = estate_agent.estate_agent_id 
                            GROUP BY accommodation.accommodation_id ORDER BY accommodation.modified DESC");
    while($row=$result->fetch_assoc()){
      $accommodation_id = $row['accommodation_id'];
      $housenumber = $row['housenumber'];
      $postcode= $row['postcode'];
      $accommodation_estate_agent = $row['estate_agent_name'];
     

      echo "
      
      <div class='col-sm-6'>
        <div class='card text-center' style ='margin-top:15px;'>
          <div class='card-body'>
            <h5 class='card-title'>$housenumber $postcode</h5>
            <p class='card-text'>Let by: $accommodation_estate_agent<br>
                                 </p>
                                 
            <a href='accommodation_page.php?accommodation_id=$accommodation_id' class='btn btn-primary btn-block form-btn' style='background-color:#7047d7;'>See reviews</a>
            
          </div>
        </div>
      </div>
      ";
    }
}
}


function getAccommodationEstateAgents(){
    if(isset($_GET['accommodation_estate_agent'])){

        global $conn;
        $accommodation_estate_agent_name = $_GET['accommodation_estate_agent'];

        $get_estate_agent = $conn->prepare("SELECT * From accommodation Left Join estate_agent On accommodation.accommodation_estate_agent = estate_agent.estate_agent_id 
                                            WHERE accommodation.accommodation_estate_agent = ? 
                                            GROUP BY accommodation.accommodation_id ORDER BY accommodation.modified DESC");
        $get_estate_agent->bind_param('i', $accommodation_estate_agent_name);

        $get_estate_agent->execute();

        $result = $get_estate_agent->get_result();

         if(!$result){
         echo $conn->query;
        }
       while($row = $result->fetch_assoc()){
    


            $accommodation_id = $row['accommodation_id'];
            $housenumber = $row['housenumber'];
            $postcode = $row['postcode'];
            $accommodation_estate_agent = $row['estate_agent_name'];
            

            echo "
            <div class='col-sm-6'>
              <div class='card text-center' style ='margin-top:25px;'>
                <div class='card-body'>
                  <h5 class='card-title'>$housenumber $postcode</h5>
                  <p class='card-text'>Let by: $accommodation_estate_agent <br>
                  </p>
                                       
                  <a href='accommodation_page.php?accommodation_id=$accommodation_id' class='btn btn-primary btn-block form-btn' style='background-color:#7047d7;'>See reviews</a>
                </div>
              </div>
              </div>
            
           
            ";
          }
      
      
}
}

function getAccommodationType(){
  if(isset($_GET['accommodation_type'])){

      global $conn;
      $accommodation_type= $_GET['accommodation_type'];

      $get_accommodation_type = $conn->prepare("SELECT * From accommodation Left Join estate_agent On accommodation.accommodation_estate_agent = estate_agent.estate_agent_id 
                                                JOIN accommodation_type WHERE accommodation.accommodation_type = ? 
                                                GROUP BY accommodation.accommodation_id ORDER BY accommodation.modified DESC");
      $get_accommodation_type ->bind_param('i', $accommodation_type);

      $get_accommodation_type ->execute();

      $result = $get_accommodation_type ->get_result();

       if(!$result){
       echo $conn->query;
      }
     while($row = $result->fetch_assoc()){
  
          $accommodation_id = $row['accommodation_id'];
          $housenumber = $row['housenumber'];
          $postcode = $row['postcode'];
          $accommodation_estate_agent = $row['estate_agent_name'];
          $accommodation_type  = $row['description'];
          

          echo "
          <div class='col-sm-6'>
            <div class='card text-center' style ='margin-top:25px;'>
              <div class='card-body'>
                <h5 class='card-title'>$housenumber $postcode</h5>
                <p class='card-text'>Let by: $accommodation_estate_agent <br>
                </p>
                                     
                <a href='accommodation_page.php?accommodation_id=$accommodation_id' class='btn btn-primary btn-block form-btn' style='background-color:#7047d7;'>See reviews</a>
              </div>
            </div>
            </div>
          
         
          ";
        }
    
    
}
}


function getNumberOfRequests(){
  global $conn;
      $result = $conn->query("SELECT COUNT(accommodation_review_request.request_id) AS NumberOfRequests FROM `accommodation_review_request`");
  
  
           while($row = $result -> fetch_assoc()) {
                      $number_of_requests = $row['NumberOfRequests'];
                      
                      
                      echo "$number_of_requests";
                      }
                  }
  
?>