<?php
$pw = "hQwgsdBbKH6cTJfK";

$user = "wwhyte01";

$webserver = "wwhyte01.lampt.eeecs.qub.ac.uk";

$db = "wwhyte01";


$servername = "wwhyte01.lampt.eeecs.qub.ac.uk";
$username = "wwhyte01";
$password = "hQwgsdBbKH6cTJfK";

try {
    $conn = new PDO("mysql:host=$servername;dbname=wwhyte01", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }




//$conn = new PDO($webserver, $user, $pw, $db);

// if ($conn) {
//     echo 'conected';
//   } else {
//     echo 'not connected';
//   }

// if($conn->connect_error){
//     echo "Connection failed: " .$conn->connect_error;
// }

?>