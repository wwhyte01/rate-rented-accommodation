<?php 
session_start();
ob_start();
include_once("db_connect.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<link rel="stylesheet" href="../assets/fontawesome/css/fontawesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<link rel="shortcut icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
   
<!-- jQuery -->
<title>Registration</title>
<script type="text/javascript" src="script/validation.min.js"></script>
<!-- <script type="text/javascript" src="script/register.js"></script>
<script type="text/javascript" src="login/script/login.js"></script> -->
<script type="text/javascript" src="script/general.js"></script>
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">


  <!--NAV BAR-->
  <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                      <!-- <a class="nav-link" href="#">Login/Register</a> -->
                    </li>
                    <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
          Help
        </a>
        
        <div class="dropdown-menu help-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" style='background-color:#7047d7;'>Contact admin on wwhyte01@qub.ac.uk</a>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "../results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav>
      <!--NAV BAR FINISH-->

<div class="container">
	<div class="signup-cover" style="margin-top: 30px;">
                  <div class="card">
                      <div class="card-header">
                          <div class="row">
                              <div class="col-md-9">
                                  <h3 class="form-heading">Register here</h3>
                                  <p>Create your account</p>
                              </div><!--col-->
                              <div class="col-md-3 text-right">
                                  <i class="fas fa-edit fa-3x"></i>

                              </div><!--col-->

                          </div><!--row-->

											</div><!--card-header-->		
											<div class="card-body">
	
	<div class="register_container">
	<form class="form-signin" method="post" id="register-form">
	<div id="error">
	</div>
	<div class="form-group">
	<input type="text" class="form-control" placeholder="Username" name="username" id="username" />
	</div>
	<div class="form-group">
	<input type="email" class="form-control" placeholder="Email address" name="email" id="email" />
	<span id="check-e"></span>
	</div>
	<div class="form-group">
	<input type="password" class="form-control" placeholder="Password (minimum 6 characters long)" name="password_1" id="password_1" />
	</div>
	<div class="form-group">
	<input type="password" class="form-control" placeholder="Retype Password" name="password_2" id="password_2" />
	</div>
	<hr />
	<div class="form-group">
	<button type="submit"  class="btn btn-success btn-block form-btn" name="register-btn" id="btn-submit">
	<span class="glyphicon glyphicon-log-in"></span> &nbsp; Create Account
	</button> 
	</div> 
	<a href="#" id="signup">Already registered?</a> 
	</form>
	</div>
</div>
</div>
</div>


<div class="login-cover" style="margin-top: 30px;">
                        <div class="card">
                                <div class="card-header">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <h3 class="form-heading">Login</h3>
                                            <p>Enter Email and Password</p>
                                        </div><!--col-->
                                        <div class="col-md-3 text-right">
                                            <i class="fas fa-lock fa-3x"></i>
          
                                        </div><!--col-->
          
                                    </div><!--row-->
          
                                </div><!--card-header-->
                              
                              <div class="card-body">


                                  <form class="form-login" method="post" id="login-form">
		<div id="login_error">
		</div>
		<div class="form-group">
			<input type="email" class="form-control" placeholder="Email address" name="email" id="email" />
			<span id="check-e"></span>
		</div>
		<div class="form-group">
			<input type="password" class="form-control" placeholder="Password" name="password" id="password" />
		</div>
		<hr />
		<div class="form-group">
			<button type="submit"  class="btn btn-success btn-block form-btn" name="login_button" id="login_button">
			<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
      </button> 
      <hr />
      <a href="#" id="login">Register?</a>
		</div> 
	</form>		
          
                              </div><!--card body-->
          
                              
                            </div><!--card-->

                  </div><!--login-cover-->
		
		
</div>

</div>



</body>
</html>

<?php
//initilaise errors
       $errors = array(); 

       if (count($errors) > 0) : ?>
       <div class="error">
           <?php foreach ($errors as $error) : ?>
             <p><?php echo $error ?></p>
               <?php endforeach ?>
 </div>
<?php  endif ?> 


<?php
//Update Account 

if(isset($_POST['register-btn'])) {

    // receive all input values from the form


 	$username = mysqli_real_escape_string($conn, $_POST['username']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
     
  $password_1 = mysqli_real_escape_string($conn, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($conn, $_POST['password_2']);
   
   
     //$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
     

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); echo "Username required"; }
  if (empty($email)) { array_push($errors, "Email is required"); echo "Email required"; }

  if (empty($password_1)) { array_push($errors, "Password is required"); echo "Password required"; }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match"); echo "Passwords do not match";
  }

  //ensure the password length is at least 6 characters long
  if (strlen($password_1) < 6){ array_push($errors, "Password of 6 characters is required");
    echo "<script>
    alert('Password must have 6 or more characters');
     </script>";
  }


    // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists"); echo "Username already exists";
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists"); echo "Email already taken";
    }
  }

    // Update user if there are no errors in the form
    if (count($errors) == 0) {
        $password = password_hash($password_1, PASSWORD_DEFAULT);//encrypt the password before saving in the database

        $insert_query= $conn->prepare("INSERT INTO users (username, email, password, user_type)
        VALUES (?, ?, ?, 1)");
        
        echo $conn->error;

        $insert_query->bind_param('sss',$username, $email, $password); 
        $insert_query->execute();
        $insert_query->close();

        session_destroy();


       // ob_end_flush();

    if($insert_query){
		
    echo "<script>
    alert('Account created. You can now login');
    window.opener.location.reload();

     </script>";

    }

}

}

if(isset($_POST['login_button'])) {
	$user_email = trim($_POST['email']);
	$user_password = trim($_POST['password']);
	
	$sql = "SELECT id, username, email, password FROM users WHERE email='$user_email'";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	$row = mysqli_fetch_assoc($resultset);	
		
	if(password_verify($user_password, $row['password'])){				
    header('location: ../index.php');
    ob_flush();

    $_SESSION['user_id'] = $userid;
		$_SESSION['user_session'] = $row['id'];
		$_SESSION['username'] = $row['username'];

	} else {				
		echo "<script>
    alert('Login details do not exist');

     </script>"; // wrong details 
	}		
}

?>
