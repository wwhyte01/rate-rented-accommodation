<?php
/* Database connection start */
$servername = "wwhyte01.lampt.eeecs.qub.ac.uk";
$username = "wwhyte01";
$password = "hQwgsdBbKH6cTJfK";
$dbname = "wwhyte01";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>