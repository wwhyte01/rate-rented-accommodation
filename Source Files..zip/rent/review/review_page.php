<!DOCTYPE html>
<html lang="en">
<head>
<?php
 
 session_start();
 include("../admin/admin_functions.php");
 include("../functions.php");

 error_reporting(E_ALL);
 ini_set('display_errors', 1);
 
 if(!isset($_SESSION['user_session'])){
  echo "<script>
  alert('Please log in');
   window.location.href='../index.php';
   </script>";
 } else {
 
 include_once("../registration/db_connect.php");
 $sql = "SELECT id, username, email, password FROM users WHERE id='".$_SESSION['user_session']."'";
 $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
 $user_row = mysqli_fetch_assoc($resultset);
 }

 if (!isset($_GET['accommodation']) && isset($_GET['token'])) {
  echo "<script>
  alert('Please check your request details');
   window.location.href='../index.php';
   </script>";
 }

 if (isset($_GET['accommodation']) && isset($_GET['token'])) {

  $accommodation_id = mysqli_real_escape_string($conn, $_GET['accommodation']);
  $token = mysqli_real_escape_string($conn, $_GET['token']);
  $current_tenant = $user_row['id'];

  //Check if correct accommodation and token are in URL
  //ALso check that token is not empty or has not expired
  $sql = $conn->query("SELECT current_tenant_id, accommodation_id FROM accommodation WHERE accommodation_id='$accommodation_id' AND token='$token' AND token<>'' AND tokenExpire > NOW()");
    
          //Redirect user if this row of data does not exist
          if (!$sql->num_rows > 0) {
            echo "<script>
          alert('Please check your request details');
           window.location.href='../index.php';
           </script>";

          
          } else {
            //Check if current user in session is current tenant of accommodation
            while($row=$sql->fetch_assoc()){
            $tenant_id = $row['current_tenant_id'];
              if($tenant_id!=$current_tenant){
                //Redirect if not correct user in session
                echo "<script>
                alert('Not correct user in session');
                 window.location.href='../index.php';
                 </script>";
              } 
            }

 ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Review Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    

    <link rel="shortcut icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
</head>
<body>
  <!--NAV BAR-->
         <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
          Help
        </a>
                    <?php
                    if(empty($_SESSION['user_session'])){
                        echo " <li class='nav-item'>
                      <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/registration.php#'>Login/Register</a>
                    </li>";
                    }else{
                        echo "<li class='nav-item'>
                        <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/review_request.php'>Request to Review</a>
                              </li>
                              <li class='nav-item'>
                              <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                    </li>";
                    }
                   ?>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "../results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit" name="search">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav> 

      <!--NAV BAR FINISH-->


      <div class="container">
	<div class="signup-cover" style="margin-top: 25px;">
                  <div class="card">
                      <div class="card-header">
                          <div class="row">
                              <div class="col-md-9">
                                  <h3 class="form-heading">Review Form</h3>
                                  <p>Rate your experience here and leave a comment!</p>
                                  <p>Rank each issue based on <b>rarity</b>.
                                  E.g. 1/5 = Bad case of mould. Whereas 5/5 = no mould throughout the year.</p>
                              </div><!--col-->
                              <div class="col-md-3 text-right">
                                  <i class="fas fa-edit fa-3x"></i>

                              </div><!--col-->

                          </div><!--row-->

											</div><!--card-header-->		
											<div class="card-body">
	
	<div class="request_container">
	<form action="review_page.php?accommodation=<?php echo " $accommodation_id" ?>&token=<?php echo $token ?>" method="post" id="review-page">
	<div id="error">
	</div>
    
    <div class = "row" style = "margin-top: 25px;">
    
    <div class="btn-group btn-group-toggle" style="width:90%; color: #f93d67;" data-toggle="buttons">
    <div class = "col-3"> 
  
   <h3>Rodent/Pest-free </h3>   
    </div>
    <div class = "col-9"> 
    <label class="btn btn-danger" style="width:15%; border-radius: 30px;" > 
    <input type="radio" name="cat_one_rating_number" value = "1" id="cat_one_rating_number" autocomplete="off"> 1
  </label>
  <label class="btn" style="width:15%; background-color:#ffa366; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_one_rating_number" value = "2" id="cat_one_rating_number" autocomplete="off"> 2
  </label>
  <label class="btn btn-warning" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_one_rating_number" value = "3" id="cat_one_rating_number" autocomplete="off"> 3
  </label>
  <label class="btn" style="width:15%; background-color:#bfff80; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_one_rating_number" value = "4" id="cat_one_rating_number" autocomplete="off"> 4
  </label>
  <label class="btn btn-success" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_one_rating_number" value = "5" id="cat_one_rating_number" autocomplete="off"> 5
  </label>
 
  </div>
</div>
</div>
<hr />


<div class = "row" style = "margin-top: 25px;">
    <div class="btn-group btn-group-toggle" style="width:90%; color: #f93d67;" data-toggle="buttons">
    <div class = "col-3">
    <h3>Damp/ Mould- free</h3>  
                </div>
                <div class = "col-9">
    <label class="btn btn-danger" style="width:15%; border-radius: 30px;" > 
    <input type="radio" name="cat_two_rating_number" id = "cat_two_rating_number" value = "1" autocomplete="off"> 1
  </label>
  <label class="btn" style="width:15%; background-color:#ffa366; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_two_rating_number" id = "cat_two_rating_number" value = "2" autocomplete="off"> 2
  </label>
  <label class="btn btn-warning" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_two_rating_number" id = "cat_two_rating_number" value = "3" autocomplete="off"> 3
  </label>
  <label class="btn" style="width:15%; background-color:#bfff80; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_two_rating_number" id = "cat_two_rating_number" value = "4" autocomplete="off"> 4
  </label>
  <label class="btn btn-success" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_two_rating_number" id = "cat_two_rating_number" value = "5" autocomplete="off"> 5
  </label>
                </div>
</div>
</div>
<hr />

<div class = "row" style = "margin-top: 25px;">
    <div class="btn-group btn-group-toggle" style="width:90%; color: #f93d67;" data-toggle="buttons">
    <div class = "col-3">
        <h3>No Water/ Heating issues</h3>
    
                </div>
                <div class = "col-9">
    <label class="btn btn-danger" style="width:15%; border-radius: 30px;" > 
    <input type="radio" name="cat_three_rating_number" id= "cat_three_rating_number" value = "1" autocomplete="off"> 1
  </label>
  <label class="btn" style="width:15%; background-color:#ffa366; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_three_rating_number" id= "cat_three_rating_number" value = "2" autocomplete="off"> 2
  </label>
  <label class="btn btn-warning" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_three_rating_number" id= "cat_three_rating_number" value = "3" autocomplete="off"> 3
  </label>
  <label class="btn" style="width:15%; background-color:#bfff80; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_three_rating_number" id= "cat_three_rating_number" value = "4" autocomplete="off"> 4
  </label>
  <label class="btn btn-success" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_three_rating_number" id= "cat_three_rating_number" value = "5" autocomplete="off"> 5
  </label>
                </div>
</div>
</div>
<hr />

<div class = "row" style = "margin-top: 25px;">
    <div class="btn-group btn-group-toggle" style="width:90%; color: #f93d67;" data-toggle="buttons">
    <div class = "col-3">
        <h3>Lack of Security Issues </h3>
     
                </div>
                <div class = "col-9">
    <label class="btn btn-danger" style="width:15%; border-radius: 30px;" > 
    <input type="radio" name="cat_four_rating_number" id="cat_four_rating_number" value = "1" autocomplete="off"> 1
  </label>
  <label class="btn" style="width:15%; background-color:#ffa366; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_four_rating_number" id="cat_four_rating_number" value = "2" autocomplete="off"> 2
  </label>
  <label class="btn btn-warning" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_four_rating_number" id="cat_four_rating_number" value = "3" autocomplete="off"> 3
  </label>
  <label class="btn" style="width:15%; background-color:#bfff80; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_four_rating_number" id="cat_four_rating_number" value = "4" autocomplete="off"> 4
  </label>
  <label class="btn btn-success" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_four_rating_number" id="cat_four_rating_number" value = "5" autocomplete="off"> 5
  </label>
                </div>
</div>
</div>
<hr/>

<div class = "row" style = "margin-top: 25px;">
    <div class="btn-group btn-group-toggle" style="width:90%; color: #f93d67;" data-toggle="buttons">
    <div class = "col-3">
        <h3>
    No Landlord issues/ unreliability </h3>
                </div>
                <div class = "col-9">
    <label class="btn btn-danger" style="width:15%; border-radius: 30px;" > 
    <input type="radio" name="cat_five_rating_number" id="cat_five_rating_number" value = "1" autocomplete="off"> 1
  </label>
  <label class="btn" style="width:15%; background-color:#ffa366; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_five_rating_number" id="cat_five_rating_number" value = "2" autocomplete="off"> 2
  </label>
  <label class="btn btn-warning" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_five_rating_number" id="cat_five_rating_number" value = "3" autocomplete="off"> 3
  </label>
  <label class="btn" style="width:15%; background-color:#bfff80; color:black; border-radius: 30px;"> 
    <input type="radio" name="cat_five_rating_number" id="cat_five_rating_number" value = "4" autocomplete="off"> 4
  </label>
  <label class="btn btn-success" style="width:15%; border-radius: 30px;"> 
    <input type="radio" name="cat_five_rating_number" id="cat_five_rating_number" value = "5" autocomplete="off"> 5
  </label>
                </div>
</div>
</div>

    
    <hr />
    
    <div class="form-group">
    <label for="comments"><h5 style=color:#7047d7>Leave a comment </h5></label>
    <textarea class="form-control" name="comments" id="comments" rows="3"></textarea>
  </div>

	<div class="form-group">
	<button type="submit"  class="btn btn-success btn-block form-btn" name="review_form" id="btn-submit">Submit Review</button> 
	</div>
	</form>
	</div>
</div>
</div>
</div>

      </body>
</html>

<?php
  $cat_one_rating = "";
  $cat_two_rating = "";
  $cat_three_rating = "";
  $cat_four_rating= "";
  $cat_five_rating = "";

if (isset($_POST['review_form'])) {

  // receive all input values from the form

  // as long as ALL ratings answered.
  //comments are optional

  if(empty($_POST['cat_one_rating_number']) || empty($_POST['cat_two_rating_number']) || empty($_POST['cat_three_rating_number']) || empty($_POST['cat_four_rating_number']) || empty($_POST['cat_five_rating_number'])){
     echo "<script>
    alert('Answer all questions please')
		</script>";
  } else {

  //initialise inputs
  $cat_one_rating = mysqli_real_escape_string($conn, $_POST['cat_one_rating_number']);
  $cat_two_rating = mysqli_real_escape_string($conn, $_POST['cat_two_rating_number']);
  $cat_three_rating = mysqli_real_escape_string($conn, $_POST['cat_three_rating_number']);
  $cat_four_rating= mysqli_real_escape_string($conn, $_POST['cat_four_rating_number']);
  $cat_five_rating = mysqli_real_escape_string($conn, $_POST['cat_five_rating_number']);
  $comments = mysqli_real_escape_string($conn, $_POST['comments']);


  //Check category one input is 1-5
  if($cat_one_rating == 1 || $cat_one_rating == 2 || $cat_one_rating == 3 ||$cat_one_rating == 4 || $cat_one_rating == 5  ){

$insert_rating_one = $conn->prepare("INSERT INTO review_category_one (tenant_id, accommodation_id, cat_one_rating_number, created, modified)
                               VALUES (?, ?, ?, NOW(), NOW())");

echo $conn->error;

$insert_rating_one->bind_param("iii", $current_tenant, $accommodation_id, $cat_one_rating);

$insert_rating_one->execute();
$insert_rating_one->close();


  }

    //Check category two input is 1-5
    if($cat_two_rating == 1 || $cat_two_rating == 2 || $cat_two_rating == 3 ||$cat_two_rating == 4 || $cat_two_rating == 5  ){

      $insert_rating_two = $conn->prepare("INSERT INTO review_category_two (tenant_id, accommodation_id, cat_two_rating_number, created, modified)
                               VALUES (?, ?, ?, NOW(), NOW())");



$insert_rating_two->bind_param("iii", $current_tenant, $accommodation_id, $cat_two_rating);

$insert_rating_two->execute();
$insert_rating_two->close();

}
  //Check category three input is 1-5
    if($cat_three_rating == 1 || $cat_three_rating == 2 || $cat_three_rating == 3 ||$cat_three_rating == 4 || $cat_three_rating == 5  ){

      $insert_rating_three = $conn->prepare("INSERT INTO review_category_three (tenant_id, accommodation_id, cat_three_rating_number, created, modified)
                               VALUES (?, ?, ?, NOW(), NOW())");

$insert_rating_three->bind_param("iii", $current_tenant, $accommodation_id, $cat_three_rating);


$insert_rating_three->execute();
$insert_rating_three->close();

}

  //Check category four input is 1-5
    if($cat_four_rating == 1 || $cat_four_rating == 2 || $cat_four_rating == 3 ||$cat_four_rating == 4 || $cat_four_rating == 5  ){

      
  $insert_rating_four = $conn->prepare("INSERT INTO review_category_four (tenant_id, accommodation_id, cat_four_rating_number, created, modified)
                               VALUES (?, ?, ?, NOW(), NOW())");

$insert_rating_four->bind_param("iii", $current_tenant, $accommodation_id, $cat_four_rating);


$insert_rating_four->execute();
$insert_rating_four->close();
      

}

  //Check category five input is 1-5
    if($cat_five_rating == 1 || $cat_five_rating == 2 || $cat_five_rating == 3 ||$cat_five_rating == 4 || $cat_five_rating == 5  ){

      
      $insert_rating_five = $conn->prepare("INSERT INTO review_category_five (tenant_id, accommodation_id, cat_five_rating_number, created, modified)
                               VALUES (?, ?, ?, NOW(), NOW())");

$insert_rating_five->bind_param("iii", $current_tenant, $accommodation_id, $cat_five_rating);


$insert_rating_five->execute();
$insert_rating_five->close();

}
 //Insert comment if all other inputs are not empty
 $get_estate_agent = $conn->prepare('SELECT accommodation.accommodation_estate_agent FROM accommodation WHERE accommodation_id = ?');
 $get_estate_agent->bind_param('i', $accommodation_id);

 $get_estate_agent->execute();

 $result = $get_estate_agent->get_result();
 while ($row = $result->fetch_assoc()) {
     $estate_agent_id = $row['accommodation_estate_agent'];
     $replies = '';
     $reply_date = '';

     $insert_comment= $conn->prepare("INSERT INTO comments_replies (tenant_id, accommodation_id, estate_agent_id, comments, replies, comment_date, reply_date)
     VALUES (?, ?, ?, ?, ?, NOW(), ?)");

echo $conn->error;

$insert_comment->bind_param("iiisss", $current_tenant, $accommodation_id, $estate_agent_id, $comments, $replies, $reply_date);


$insert_comment->execute();
$insert_comment->close();
 
echo "<script>
alert('Review added successfully!');
 window.location.href='../index.php';
 </script>";

 }

 //Reset Token once user submits form
$reset_token = $conn->prepare('UPDATE accommodation SET token = NULL WHERE accommodation_id = ?');
$reset_token->bind_param('i', $accommodation_id);
$reset_token->execute();
$result = $reset_token->get_result();

 //Update Last modified column
 $last_modified = $conn->prepare('UPDATE accommodation SET modified = NOW() WHERE accommodation_id = ?');
 $last_modified->bind_param('i', $accommodation_id);
 $last_modified->execute();
 $result = $last_modified->get_result();


}
}
 } 
 }

    ?>
 