<!DOCTYPE html>
<html lang="en">
<head>
<?php
 
 session_start();

 include("functions.php");
 if(!isset($_GET['accommodation_id'])){
  header("Location: index.php");
 }
 if(isset($_SESSION['user_session'])){

 
 
 include_once("registration/db_connect.php");
 $sql = "SELECT * FROM users WHERE id='".$_SESSION['user_session']."'";
 $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
 $user_row = mysqli_fetch_assoc($resultset);
 $logged_in_username = $user_row['username'];
 global $logged_in_username;
 }

 ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Accommodation Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/styles_index.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    

    <link rel="shortcut icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
</head>
<body>
  <!--NAV BAR-->
         <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0 ">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
          Help
        </a>
        
        <div class="dropdown-menu help-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" style='background-color:#7047d7;'>Contact admin on wwhyte01@qub.ac.uk</a>
                    <?php
 
              if(empty($_SESSION['user_session'])){
                    echo " <li class='nav-item'>
                  <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/registration.php#'>Login/Register</a>
                </li>";
              }elseif ($_SESSION['user_session'] == '61'){
                echo "<li class='nav-item'>
                    <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/admin/manage_reviews.php'>Manage Reviews <span class='badge badge-light'>";
                     getNumberOfRequests();
                     echo "</span></a>
                          </li>
                          <li class='nav-item'>
                          <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                </li>";

                }elseif ($user_row['user_type'] == '2'){
                    echo "<li class='nav-item'>
                    <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/manage_profile.php'>Manage Profile</a>
                          </li>
                          <li class='nav-item'>
                          <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                </li>";
                }else {
                 echo" <li class='nav-item'>
                    <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/review_request.php'>Request to Review</a>
                          </li>
                          <li class='nav-item'>
                    <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/manage_profile.php'>Manage Profile</a>
                          </li>
                          <li class='nav-item'>
                          <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                </li>";
                }
                   ?>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit" name="search">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav> 

      <!--NAV BAR FINISH-->


                                                                               <!--MAIN BODY-->
                      <!--sidebar -->
      <div class="container">
        
         <div class="row">
          
    <div class="col-sm-3" name="sidebar">
      <br>
      
    <?php if(isset($_SESSION['user_session'])){  echo "Welcome ". $user_row['username']. "<hr />";} ?>
    <h3 class="sidebar-heading" style="color:#7047d7;">Filter by </h3>
    <br> <br>
        
    <h6 class="sidebar- subheading" style="color: #f93d67">Accommodation Type:</h6>
                    <!--Getting list of accommodation types -->
                    <?php getAccommodationTypeID(); ?>
    <br>

                    <!--Getting the list of estate agents -->
    <h6 class="sidebar- subheading" style="color: #f93d67">Estate Agents/ Landlords:</h6>
                   <?php  getEstateAgents();?>

                    <!--Main -->
        <?php

        if(isset($_GET['accommodation_id'])){
            $accommodation_id = $_GET['accommodation_id'];

            $accommodation_details = $conn->prepare('SELECT * FROM accommodation WHERE accommodation.accommodation_id = ?');
            $accommodation_details->bind_param('i', $accommodation_id);

            $accommodation_details->execute();

            $result = $accommodation_details->get_result();
            while ($row = $result->fetch_assoc()) {
                  $accommodation_id = $row['accommodation_id'];
                  $housenumber = $row['housenumber'];
                  $postcode = $row['postcode'];
                  $accommodation_created = $row['created'];
                  $accommodation_modified = $row['modified']; 
            }
                
                ?>
    </div>
    

                  
    <div class="col-sm-9">
            <div class="row">
            
            <h3 class="main-subheading" style="color:#7047d7;  margin-top:25px;"><?php echo "$housenumber $postcode";           
        }
        ?> </h3> 
      
     
        </div>

                                                                <!--Getting the total reviews and created/last modified data-->

<?php

    $overall_rating = 0;
    $category_one_average = 0;
    $category_two_average = 0;
    $category_three_average = 0;
    $category_four_average = 0;
    $category_five_average = 0;

    $accommodation_id = $_GET['accommodation_id'];
    


    $accommodation_details = $conn->prepare("SELECT COUNT(review_category_one.accommodation_id) AS 'total_reviews' FROM review_category_one
                                            WHERE review_category_one.accommodation_id = ?");
    $accommodation_details->bind_param('i', $accommodation_id);
    $accommodation_details->execute();
    $result = $accommodation_details->get_result();
    
    while ($row = $result->fetch_assoc()) {
          $total_reviews = $row['total_reviews'];
          echo "<div class='row' style = 'color: #f93d67';>
                <div class='col'>
                 $total_reviews Review(s)
                 </div>
                 <hr />
                 ";
    }
    

    $accommodation_id = $_GET['accommodation_id'];

    $get_accommodation_estate_agent = $conn->prepare("SELECT * FROM `estate_agent` JOIN accommodation WHERE accommodation.accommodation_estate_agent = estate_agent.estate_agent_id AND accommodation.accommodation_id = ?");
    $get_accommodation_estate_agent->bind_param('i', $accommodation_id);

    $get_accommodation_estate_agent->execute();

    $result = $get_accommodation_estate_agent->get_result();
    while ($row = $result->fetch_assoc()) {
    $accommodation_estate_agent_id = $row['estate_agent_id'];
    $accommodation_estate_agent = $row['estate_agent_name'];
    echo "<div class='col' style = 'color: #f93d67';> 
    Landlord: <a href='#' style='color:#7047d7;'> $accommodation_estate_agent</a>
    

     </div>
     ";
}
?> </div>
                                                                     <!--Getting the created/last modified times -->
        
        <div class='row'>
        <div class = 'col'>

        
        <p style = "margin-bottom:25px">Created: <?php echo "$accommodation_created"; ?> </p> </div>
        <div class = 'col'>
        <p style = "margin-bottom:25px"> Last modified: <?php echo "$accommodation_modified"; ?></p></div>
      
    </div>
                                                                  <!-- Getting Accommodation image -->

    <div class='row' style="margin-bottom: 25px;">

    <div class = 'col-2'></div>
    <?php

    $accommodation_id = $_GET['accommodation_id'];

    $get_accommodation_image = $conn->prepare("SELECT image FROM `accommodation` WHERE accommodation_id = ?");
    $get_accommodation_image->bind_param('s', $accommodation_id);

    $get_accommodation_image->execute();

    $result = $get_accommodation_image->get_result();
    while ($row = $result->fetch_assoc()) {
    $accommodation_image= $row['image'];

    echo "<div class = 'col-6'>
    <img src='accommodation_images/$accommodation_image' style='width:100%;height:100%; border-radius: 30px;'>
    </div>
    ";
    }
    ?>
    <div class = 'col-4'></div>
    
    </div>

                                                                       <!--Getting the accommodation reviews -->
                   <div class="card">
                  <div class="card-header"> <h3>Score Breakdown </h3> Based on the <b>rarity</b> of these common issues </div>
                  <div class="card-body">

                   <div class= 'container'>
                   <div class = 'row'>
                   <div class = 'col'>

                   <?php  
                          $accommodation_id = $_GET['accommodation_id'];
                          $get_category_one = $conn->prepare("SELECT ROUND(AVG(cat_one_rating_number), 1) AS 'rating_one_avg' FROM `review_category_one` WHERE accommodation_id = ?");
                          $get_category_one->bind_param('i', $accommodation_id);

                          $get_category_one->execute();
                 
                          $result = $get_category_one->get_result();

                   while($row = $result->fetch_assoc()){
                       $category_one_average = $row['rating_one_avg']; ?>
                       <?php echo "<dl class = 'row'>
                       <dt class='col-12 col-md-5'><h6>Rodent/Pest-free: </h6></dt>
                       <dd class='col-6 col-md-7' style='text-align :right;'><b  style='color:#7047d7;font-size:x-large;' >$category_one_average</b> /5</dd>
                       </dl> <hr />"; } ?>  


                    
                   <?php
                   
                   $accommodation_id = $_GET['accommodation_id'];
                   $get_category_two = $conn->prepare("SELECT ROUND(AVG(cat_two_rating_number), 1) AS 'rating_two_avg' FROM `review_category_two` WHERE accommodation_id = ?");
                   $get_category_two->bind_param('i', $accommodation_id);

                   $get_category_two->execute();
          
                   $result = $get_category_two->get_result();

            while($row = $result->fetch_assoc()){
                        $category_two_average = $row['rating_two_avg']; ?>
                        <?php echo "<dl class = 'row'>
                       <dt class='col-12 col-md-5'><h6>Damp/Mould-free: </h6></dt>
                       <dd class='col-6 col-md-7' style='text-align :right;'><b  style='color:#7047d7;font-size:x-large;' > $category_two_average</b> /5</dd>
                       </dl> <hr />"; } ?> 

                    <?php
                    
                    $accommodation_id = $_GET['accommodation_id'];
                    $get_category_three = $conn->prepare("SELECT ROUND(AVG(cat_three_rating_number), 1) AS 'rating_three_avg' FROM `review_category_three` WHERE accommodation_id = ?");
                    $get_category_three->bind_param('i', $accommodation_id);
 
                    $get_category_three->execute();
           
                    $result = $get_category_three->get_result();
 
             while($row = $result->fetch_assoc()){
                         $category_three_average = $row['rating_three_avg']; ?>
                        <?php echo "<dl class = 'row'>
                       <dt class='col-12 col-md-5'><h6>No Water/Heating issues: </h6></dt>
                       <dd class='col-6 col-md-7' style='text-align :right;'><b  style='color:#7047d7;font-size:x-large;' > $category_three_average</b> /5</dd>
                       </dl> <hr />"; } ?> 

</div>
<div class='col'>

                    <?php 
                         
                    $accommodation_id = $_GET['accommodation_id'];
                    $get_category_four = $conn->prepare("SELECT ROUND(AVG(cat_four_rating_number), 1) AS 'rating_four_avg' FROM `review_category_four` WHERE accommodation_id = ?");
                    $get_category_four->bind_param('i', $accommodation_id);
 
                    $get_category_four->execute();
           
                    $result = $get_category_four->get_result();
 
             while($row = $result->fetch_assoc()){
                        $category_four_average = $row['rating_four_avg']; ?>
                        <?php echo "<dl class = 'row'>
                       <dt class='col-12 col-md-5'><h6>Lack of Security Issues: </h6></dt>
                       <dd class='col-6 col-md-7' style='text-align :right;'><b  style='color:#7047d7;font-size:x-large;' > $category_four_average</b> /5 </dd>  
                       </dl> <hr />"; } ?> 

                    <?php 
                                 
                    $accommodation_id = $_GET['accommodation_id'];
                    $get_category_five = $conn->prepare("SELECT ROUND(AVG(cat_five_rating_number), 1) AS 'rating_five_avg' FROM `review_category_five` WHERE accommodation_id = ?");
                    $get_category_five->bind_param('i', $accommodation_id);
 
                    $get_category_five->execute();
           
                    $result = $get_category_five->get_result();
 
             while($row = $result->fetch_assoc()){
                        $category_five_average = $row['rating_five_avg']; ?>
                        <?php echo "<dl class = 'row'>
                       <dt class='col-12 col-md-5'><h6>No Landlord issues/ unreliability: </h6></dt>
                       <dd class='col-6 col-md-7' style='text-align :right;'><b  style='color:#7047d7;font-size:x-large;' > $category_five_average</b> /5 </dd>  
                       </dl> <hr />"; } ?> 

<?php 
                                              
                                    $overall_rating = ($category_one_average + $category_two_average + $category_three_average+ $category_four_average + $category_five_average) / 5;
                                                                      
                                   echo "<dl class = 'row'>
                                    <dt class='col-12 col-md-5'><h6>OVERALL: </h6></dt>
                                    <dd class='col-6 col-md-7' style='text-align :right;'><b  style='font-size:x-large; color: #f93d67'>$overall_rating</b>  /5 </dd>  
                                    </dl> <hr />"; ?> 

</div>
</div>
</div>
</div>
</div>
                                                                              <!-- Getting the comment sections -->
                 

                <div class="card"style= "margin-top:25px;">
                  <div class="card-header"> <h3>Comments</h3> </div>
                  <div class="card-body">

                 <?php

                    $accommodation_id = $_GET['accommodation_id'];
                    $get_comments = $conn->prepare("SELECT * FROM comments_replies LEFT JOIN users ON comments_replies.tenant_id = users.id JOIN estate_agent ON comments_replies.estate_agent_id = estate_agent.estate_agent_id WHERE comments_replies.accommodation_id =?");
                    $get_comments->bind_param('i', $accommodation_id);

                    $get_comments->execute();

                    $result = $get_comments->get_result();

                    while($row = $result->fetch_assoc()){
                    $comment_reply_id = $row['comments_replies_id'];
                     $comments = $row['comments'];
                     $usernames = $row['username'];
                     $comment_date = $row['comment_date'];
                     $replies = $row['replies'];
                     $reply_date= $row['reply_date'];
                     $estate_agent_name = $row['estate_agent_name'];
                    

                     echo " <dl class='row'>
                     <dt class='col-sm-9'>"; 
                    if(empty($row['comments'])){
                      echo "No written comment";
                    } else{
                      echo "$comments";
                    }
                       
                      echo " <dd class='row'>
                         <dd class='col-8 col-sm-6'>
                           <b style = 'color: #f93d67'; >$usernames</b>
                         </dd>
                         <dd class='col-4 col-sm-6'>";
                         if($row['comment_date']== '0000-00-00'){
                          echo "";
                        } else{
                          echo "$comment_date";
                        }
                          echo "
                         </dd>
                       </dd>
                     </dt>

                     <dt class='col-sm-12' style = 'background-color: #f9ebf2;'>";
                     


                     //Check if user in session is estate agent and the replies row is empty
                      if(isset($_SESSION['user_session']) && $user_row['user_type'] === '2' && empty($row['replies'])){
                      
                        // Check if user in session is estate agent of this accommodation
                        if(trim($user_row['username']) == trim($estate_agent_name)){
                          echo "$replies";

                      ?> 
                        <form action='accommodation_page.php?accommodation_id=<?php echo $accommodation_id?>' method='post' id='add_reply'>
                       <div class='form-group'>
                      <label for='reply'><h5 style=color:#7047d7>Reply to comment </h5></label>

                        <!--Ensure input type is an array since the form is in while loop -->
                      <input type="hidden" name="id[]" value="<?php echo $comment_reply_id ?>" id= "reply_id" />
                      <textarea class='form-control' name='replies[]' value='<?php echo $replies ?>' id='replies' rows='3'></textarea>
                    </div>
                  
                    <div class='form-group'>
                    <button type='submit'  class='btn btn-success btn-block form-btn' name='reply_button' value="<?php $comment_reply_id?>" id='btn'>Leave Reply</button> 
                    </div>
                    </form>
                  
<?php                   echo "$replies";
                        }  
                }elseif(empty($row['replies'])){
                    echo "No reply"; 
                 } 
                  else{
                      echo "$replies";
                    }
                       echo "
                      
                         <dd class='col-8 col-sm-6' style = 'background-color: #f9ebf2;'>
                           <b style = 'color: #f93d67;' style = 'background-color: #f9ebf2;' >$estate_agent_name</b>
                         
                         <dd class='col-4 col-sm-6' style = 'background-color: #f9ebf2;'>";
                         if($row['reply_date']== '0000-00-00'){
                          echo "";
                        } else{
                          echo "$reply_date";
                        }
                        echo "
                         </dd>
                       </dd>
                     </dt>
                   </dl>
                   <hr /> ";
                 }
                 ?>        
                 </div>
                 </div>
    </div>
    </div>
  </div>
  </div>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/general.js"></script>
</body>
</html>

<?php

  if(isset($_POST['reply_button'])){
      $id = $_POST['id'];
      $reply = $_POST['replies'];

      
    //Loop over two arrays and assign element's keys to values
      foreach (array_combine($id, $reply) as $replyID => $update_reply){

    $insert_reply = $conn->prepare("UPDATE `comments_replies` SET `reply_date` = NOW(),  `replies` = ? WHERE `comments_replies`.`comments_replies_id` = ?");
    
    $insert_reply->bind_param('si', $update_reply, $replyID);
    $insert_reply->execute();
    $result = $insert_reply->get_result();

    //refresh page once submitted
    echo "<meta http-equiv='refresh' content='0'>";


    }
  }
?>