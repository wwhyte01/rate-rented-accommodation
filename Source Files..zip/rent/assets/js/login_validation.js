// $(document).ready(function(){
//     var name="";
//     var email="";
//     var password="";
//     var confirm="";
//     var name_reg=/^[a-z ]+$/i;
//     var email_reg=/^\S+@\S+\.\S+$/;

//     // === Username Validation ===
//     $("#name").focusout(function(){
//     var store=$.trim($("#name").val());
//     if(store.length==""){
//        $(".name-error").html("Username required");
//        $("#name").addClass("border-red");
//        $("#name").removeClass("border-green");
//        name="";
       
//     } else if(name_reg.test(store)){
//         $(".name-error").html("");
//         $("#name").addClass("border-green");
//         $("#name").removeClass("border-red");
//         name=store;
        
//     } else {
//         $(".name-error").html("Numbers are not required");
//         $("#name").addClass("border-red");
//         $("#name").removeClass("border-green");
//         name="";
        
//     }
//     }) // === End of Username Validation ===


//     // === Email Validation ===

//     $("#email").focusout(function(){
//         var email_store=$.trim($("#email").val());
//         if(email_store.length==""){
//             $(".email-error").html("Email is required");
//             $("#email").addClass("border-red");
//             $("#email").removeClass("border-green");
//             email="";

//         } else if(email_reg.test(email_store)){

//             $.ajax({
//                 type : 'POST',
//                 url : 'ajax/signup.php',
//                 dataType : 'JSON',
//                 data : {'check_email' : email_store},
//                 success : function(feedback){
//                     if(feedback['error'=='email_success']){
//                         alert("success");
//                     }else if(feedback['error'=='email_failure']){
//                         alert(feedback['message']);
//                     }
                    
//                 }

//             });
//         }else{
//             $(".email-error").html("Invalid Email Format");
//             $("#email").addClass("border-red");
//             $("#email").removeClass("border-green");
//             email="";

//         }
//     })
// })

$('document').ready(function() {
    /* handle form validation */
    $("#register-form").validate({
    rules:
    {
    user_name: {
    required: true,
    minlength: 3
    },
    password: {
    required: true,
    minlength: 8,
    maxlength: 15
    },
    cpassword: {
    required: true,
    equalTo: '#password'
    },
    user_email: {
    required: true,
    email: true
    },
    },
    messages:
    {
    user_name: "please enter user name",
    password:{
    required: "please provide a password",
    minlength: "password at least have 8 characters"
    },
    user_email: "please enter a valid email address",
    cpassword:{
    required: "please retype your password",
    equalTo: "password doesn't match !"
    }
    },
    submitHandler: submitForm
    });
    /* handle form submit */
    function submitForm() {
    var data = $("#register-form").serialize();
    $.ajax({
    type : 'POST',
    url : 'signup.php',
    data : data,
    beforeSend: function() {
    $("#error").fadeOut();
    $("#btn-submit").html('<span class="glyphicon glyphicon-transfer"></span>   sending ...');
    },
    success : function(response) {
    if(response==1){
    $("#error").fadeIn(1000, function(){
    $("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span>   Sorry email already taken !</div>');
    $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span>   Create Account');
    });
    } else if(response=="registered"){
    $("#btn-submit").html('<img src="ajax-loader.gif" />   Signing Up ...');
    setTimeout('$(".form-signin").fadeOut(500, function(){ $(".register_container").load("welcome.php"); }); ',3000);
    } else {
    $("#error").fadeIn(1000, function(){
    $("#error").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-info-sign"></span>   '+data+' !</div>');
    $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span>   Create Account');
    });
    }
    }
    });
    return false;
    }
    });



// https://stackoverflow.com/questions/201323/how-to-validate-an-email-address-using-a-regular-expression
//https://www.rexegg.com/regex-quickstart.html