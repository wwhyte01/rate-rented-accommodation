$(document).ready(function(){
    $("#login").click(function(){
        $(".signup-cover").show();
        $(".login-cover").hide();
    })

    $("#signup").click(function(){
        $(".signup-cover").hide();
        $(".login-cover").show();
    })
})