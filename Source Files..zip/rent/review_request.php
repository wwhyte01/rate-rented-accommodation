
<?php
 session_start();
 if(!isset($_SESSION['user_session'])){
      header("Location: registration/registration.php");
 }
 error_reporting(E_ALL);
 ini_set('display_errors', 1);

 include("registration/db_connect.php");

 $sql = "SELECT * FROM users WHERE id='".$_SESSION['user_session']."'";
 $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
 $row = mysqli_fetch_assoc($resultset);

 $request_current_tenant_id = $row['id'];
 



 ?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Review Request</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

    
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

    <link rel="icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
</head>
<body>
  <!--NAV BAR-->
         <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
          Help
        </a>
        
        <div class="dropdown-menu help-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" style='background-color:#7047d7;'>Contact admin on wwhyte01@qub.ac.uk</a>
                    <?php
                    if(empty($_SESSION['user_session'])){
                        echo " <li class='nav-item'>
                      <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/registration.php#'>Login/Register</a>
                    </li>";
                    }else{
                        echo " <li class='nav-item'>
                        <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                      </li>";
                    }
                   ?>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav> 

      <!--NAV BAR FINISH-->


      <!--MAIN BODY-->

      
<div class = "row" style = "margin-top: 25px;">
<div class="container" >
	<div class="signup-cover">
                  <div class="card">
                      <div class="card-header">
                          <div class="row">
                              <div class="col-md-9">
                                  <h3 class="form-heading">Request to review here</h3>
                                  <p>Please provide your address along with proof that you live there</p>
                                  <p>Tenancy agreement should clearly show dates of your contract</p>
                              </div><!--col-->
                              <div class="col-md-3 text-right">
                                  <i class="fas fa-edit fa-3x"></i>

                              </div><!--col-->

                          </div><!--row-->

											</div><!--card-header-->		
											<div class="card-body">
	
	<div class="request_container">
	<form action="review_request.php" method="post" id="request-form" enctype="multipart/form-data">
	
  <div id="error">
	</div>

    <div class="form-group">
    <input type="text" class="form-control" placeholder="House number" name="housenumber" id = "housenumber" />
    </div>
	
  <div class="form-group" id="locationField">
    <input type="text" class="form-control" placeholder="Post Code & Street Name" id="autocomplete"  onFocus="geolocate()" name="postcode" />
    </div>



    <div class="form-group">
    <select class = "form-control"placeholder="Estate Agent or Landlord" name="estate_agent" id="estate_agent" onChange="catOnchange();">
      
    <option value="" disabled selected>Select estate agent/ landlord. If not listed please select 'Other' </option>
    <script>

    //Function to display new text box to provide new estate agent details
    //if user selects 'other' in dropdown menu

    function catOnchange(){
    var cat = document.getElementById('estate_agent').value 
    if(cat == "6")
        document.getElementById("new_estate_agent").style.display="block";
    else
        document.getElementById("new_estate_agent").style.display="none";
}
 </script>
                        <?php
                        $result =  $conn->query ("SELECT * FROM estate_agent");
                        //Displaying dropdown menu of current estate agents in system
                                    while($row = $result -> fetch_assoc()) {
                                        $estate_agent_id = $row['estate_agent_id'];
                                        $estate_agent_name = $row['estate_agent_name'];
                                        echo "<option value= '$estate_agent_id' id = '$estate_agent_id'>$estate_agent_name</option>";
                                              
                                                                        } ?>
                                                                        
                                                                       

    </select>
    <input type="text" class="form-control" placeholder="Other Estate Agent or Landlord" name="new_estate_agent" id="new_estate_agent" style="display:none; margin-top: 10px;">

   
    </div>
    
    <div class="form-group">
    <!-- New form field if user selects 'Other' -->
    <select class = "form-control" name = "type" id = "type" placeholder="Type">
    <option value="" disabled selected>Select accommodation type</option>
                        <?php
                        $result =  $conn->query ("SELECT * FROM accommodation_type");
                                    while($row = $result -> fetch_assoc()) {
                                        $type_id = $row['accommodation_type_id'];
                                        $type_description = $row['description'];
                                        echo "<option value= '$type_id'>$type_description</option>";
                                              
                                                                        } ?>
                                                                        </select>
	</div>
	
  <div class="form-group">
	<input type="file" placeholder="image" name="image_to_upload" id="image_to_upload" style="display:none;" />
  <label for="image_to_upload"  class="btn btn-outline-primary">Upload photo of tenancy agreement </label>

  <input type="hidden" name="addressURL" id="addressURL" value="<?php echo $addressURL; ?>"/>

	</div>
	<hr />
	<div class="form-group">
	
  <button type="submit"  class="btn btn-success btn-block form-btn" name="review_request_button" id="btn-submit">Send Request</button> 
	
  </div>
	</form>
	</div>
</div>
</div>
</div>
    


    <script>
// This sample uses the Autocomplete widget to help the user select a
// place, then it retrieves the address components associated with that
// place, and then it populates the form fields with those details.
// This sample requires the Places library. Include the libraries=places
// parameter when you first load the API. For example:
// <script
// src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

var placeSearch, autocomplete;

var componentForm = {
  street_number: 'short_name',
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  country: 'long_name',
  postal_code: 'short_name'
};

function initAutocomplete() {
  // Create the autocomplete object, restricting the search predictions to
  // geographical location types.
  autocomplete = new google.maps.places.Autocomplete(
      document.getElementById('autocomplete'), {types: ['geocode']});

  // Avoid paying for data that you don't need by restricting the set of
  // place fields that are returned to just the address components.
  autocomplete.setFields(['address_component']);

  // When the user selects an address from the drop-down, populate the
  // address fields in the form.
  autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
  // Get the place details from the autocomplete object.
  var place = autocomplete.getPlace();

  for (var component in componentForm) {
    document.getElementById(component).value = '';
    document.getElementById(component).disabled = false;
  }

  // Get each component of the address from the place details,
  // and then fill-in the corresponding field on the form.
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
    }
  }
}

// Bias the autocomplete object to the user's geographical location,
// as supplied by the browser's 'navigator.geolocation' object.
function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      var circle = new google.maps.Circle(
          {center: geolocation, radius: position.coords.accuracy});
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5u8hyGlvg8Zf3EzKYEq80s19qvS6GV0k&libraries=places&callback=initAutocomplete"
        async defer></script>

</body>
</html>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5u8hyGlvg8Zf3EzKYEq80s19qvS6GV0k&libraries=places&callback=initAutocomplete"
        async defer></script>
        


<?php
                                                          // UPLOAD REQUEST
if (isset($_POST['review_request_button'])) {
    // receive all input values from the form
    //ensure no fields are empty

  if(empty($_POST['housenumber']) || empty($_POST['postcode']) || empty($_POST['type']) || empty($_POST['estate_agent']) 
  ){
    echo "Answer all questions please";
  } elseif($_FILES['image_to_upload']['name'] == "") {
    echo "No contract was uploaded";
    }
    
    
    
    // Ensure the file uploaded is image

elseif ($_FILES['image_to_upload']['error'] !== UPLOAD_ERR_OK) {
  die("Upload failed with error code " . $_FILES['image_to_upload']['error']);
}

  // if user selects 'other' estate agent
  // they must fill in 'other_estate_agent' field
  elseif(($_POST['estate_agent']=='6') && empty($_POST['new_estate_agent'])){
    echo "Provide an estate agent please";
  }
  
  else {
    
  //initialise inputs
  $house_number = mysqli_real_escape_string($conn, $_POST['housenumber']);
  $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
  $request_estate_agent = mysqli_real_escape_string($conn, $_POST['estate_agent']);
  $other_estate_agent = mysqli_real_escape_string($conn, $_POST['new_estate_agent']);
  $type = mysqli_real_escape_string($conn, $_POST['type']);
  $address = $house_number . ',' . $postcode;
  $addressURL ='http://maps.googleapis.com/maps/api/streetview?size=600x400&location='. $address . '&key=AIzaSyC5u8hyGlvg8Zf3EzKYEq80s19qvS6GV0k';
  
  $info = getimagesize($_FILES['image_to_upload']['tmp_name']);
if ($info === FALSE) {
  die("Unable to determine image type of uploaded file");
}

if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
  die("Not a gif/jpeg/png");
}

  
  //give image unique name
  $ran = rand(0,100000);
  $upload_contract_img = $_FILES['image_to_upload'] ['name'];
  $upload_contract_img = $ran.$upload_contract_img;

  $contract_img_tmp = $_FILES['image_to_upload'] ['tmp_name'];

  $move = move_uploaded_file($contract_img_tmp, "contract_images/".$upload_contract_img);
  if(!$move){           
    echo "Not uploaded because of error ".$_FILES["image_to_upload"]["error"];       
}

//Finally, upload if no errors
$insert_query= $conn->prepare("INSERT INTO accommodation_review_request (request_house_number, request_postcode, request_estate_agent, other_estate_agent, type, contract_image, 
                                          request_current_tenant, addressURL, request_date)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");

echo $conn->error;

$insert_query->bind_param("ssisisis", $house_number, $postcode, $request_estate_agent, $other_estate_agent, $type, $upload_contract_img, $request_current_tenant_id, $addressURL);
$insert_query->execute();
$insert_query->close();

echo "<script>
alert('Request sent! We will review it and be in touch soon');
 window.location.href='index.php';
 </script>";
    
  }
}
?>