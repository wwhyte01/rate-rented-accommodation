<?php 

// include '../conn/conn.php';
// function check_email(){
//     GLOBAL $conn;
//     if(isset($_POST['check_email'])){
//         $email=$_POST['check_email'];
//         $query=$conn->prepare("SELECT email FROM tenant WHERE email = ?");
//         $query->execute(array($email));
//         if($query->rowCount()==0){
//             echo json_encode(array('error'=>'email_success'));
//         } else {
//             echo json_encode(array('error'=>'email_failure', 'message'=> 'This email is taken'));

//         }
//     }

// }
// check_email();



include '..conn/conn.php';
if(isset($_POST['btn-save'])) {
$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];
$user_password = $_POST['password'];
$sql = "SELECT email FROM users WHERE email='$user_email'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);
if(!$row['email']){
$sql = "INSERT INTO users(`id`, `username`, `email`, `address`, `password`, 'image') VALUES (NULL, '$user_name', '$user_email', NULL, '$user_password', NULL)";
mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn)."qqq".$sql);
echo "registered";
} else {
echo "1";
}
}


?>