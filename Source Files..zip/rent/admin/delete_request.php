<?php 
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

include("request.php");


if(isset($_GET['request_id'])){

        $delete_request_id= $_GET['request_id'];

        $delete_query = $conn->prepare("DELETE FROM accommodation_review_request WHERE request_id = ?");
        $delete_query->bind_param('i', $delete_request_id);

        $delete_query->execute();

        $result = $delete_query->get_result();

        echo "<script>
        alert('Request deleted');
         window.location.href='manage_reviews.php';
         </script>";
       }
?>