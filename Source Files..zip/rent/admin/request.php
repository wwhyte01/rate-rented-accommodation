<!DOCTYPE html>
<html lang="en">
<head>
<?php
  
  if(!isset($_SESSION)) 
  { 
      session_start(); 
  } 
    include("admin_functions.php");

    error_reporting(E_ALL);
    ini_set('display_errors', 1);
 
  
 
  
  
  include_once("../registration/db_connect.php");
  $sql = "SELECT * FROM users WHERE id='".$_SESSION['user_session']."'";
  $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
  $user_row = mysqli_fetch_assoc($resultset);
 
   if($_SESSION['user_session'] != '61' && $user_row['user_type'] != '3'){
       header("Location: ../index.php");
  }
 
 ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Manage Review Requests</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    

    <link rel="shortcut icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
</head>
<body>
  <!--NAV BAR-->
         <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <?php
                    echo 
                    "<li class='nav-item'>
                              <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                    </li>";
                    
                   ?>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "../results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit" name="search">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav> 

      <!--NAV BAR FINISH-->
      <?php
      $errors = array(); 

if (count($errors) > 0) : ?>
<div class="error">
    <?php foreach ($errors as $error) : ?>
      <p><?php echo $error ?></p>
        <?php endforeach ?>
</div>
<?php  endif ?> 

         <!--Main -->
         <div class="container">
         <?php

                                        if(isset($_GET['request_id'])){
                                          $request_id = mysqli_real_escape_string($conn, $_GET['request_id']);
                                          $request_current_tenant = "";

                                        $request_details = $conn->prepare('SELECT * FROM `accommodation_review_request` WHERE accommodation_review_request.request_id = ?');
                                        $request_details->bind_param('i', $request_id);

                                        $request_details->execute();

                                        $result = $request_details->get_result();
                                        while ($row = $result->fetch_assoc()) {
                                            $request_id = $row['request_id'];
                                            $request_house_number = $row['request_house_number'];
                                            $request_postcode = $row['request_postcode'];
                                            $request_estate_agent = $row['request_estate_agent'];
                                            $request_current_tenant = $row['request_current_tenant'];
                                            $request_date = $row['request_date'];
                                        }
                                            
                                            ?>
         

         

                        <div class="card"  style="margin-top:25px;">
                                <div class="card-header">
                                    <div class="row">
                                      <div class = "col"><h3 class="form-heading">Request details for:</h3> </div>
                                      <div class = "col"><h3 class="form-heading" style="float:right;">Tenant details:</h3> </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-md-6">
                                             <?php echo " <h4>$request_house_number $request_postcode </h4>
                                                            <h6>$request_date</h6>"; }?>
                                            
                                          <?php
                                          $tenant_request_details = $conn->prepare('SELECT * FROM `accommodation_review_request` 
                                                                                  LEFT JOIN users ON accommodation_review_request.request_current_tenant = ? AND users.id= ?
                                                                                  JOIN estate_agent ON accommodation_review_request.request_estate_agent = estate_agent.estate_agent_id
                                                                                  AND accommodation_review_request.request_id = ? GROUP BY accommodation_review_request.request_id');
                                        $tenant_request_details->bind_param('iii', $request_current_tenant, $request_current_tenant, $request_id);

                                        $tenant_request_details->execute();

                                        $request_result = $tenant_request_details->get_result();
                                        while ($row = $request_result->fetch_assoc()) {
                                            $request_id = $row['request_id'];
                                            $request_house_number = $row['request_house_number'];
                                            $request_postcode = $row['request_postcode'];
                                            $estate_agent_name = $row['estate_agent_name'];
                                            $other_estate_agent = $row['other_estate_agent'];
                                            $request_current_tenant = $row['request_current_tenant'];
                                            $contract_image = $row['contract_image'];
                                            $addressURL = $row['addressURL'];
                                            $tenant_id = $row['id'];
                                            $tenant_username = $row['username'];
                                            $tenant_email = $row['email'];
                                            


                                            ?>


                                        
                                        </div><!--col-->
                                        <div class="col-md-6 text-right">
                                          <?php
                                          echo "<h4>$tenant_email </h4> <h5>$tenant_username </h5>   ";
                                          
                                            ?>
                                            
          
                                        </div><!--col-->
          
                                    </div><!--row-->
          
                                </div><!--card-header-->
                              
                                                       <div class="card-body">
                                                         <div class= "row"> 


                                                         <?php if($estate_agent_name == 'Other'){
                                                           
                                                         echo "
                                                         <div class='col'> 
                                                         <h3 style= 'color: red;'>Estate Agent / Landlord not in system </h3>
                                                         
                                                         </div>
                                                         <div class = 'col'>
                                                         
                                                         <b>  $other_estate_agent</b> <p>Add them to system in form below</p>";
                                                          } else {
                                                          echo "
                                                          <div class='col'> 
                                                          <h3>Estate Agent / Landlord: </h3></div>
                                                          <div class = 'col'>
                                                          <h4>$estate_agent_name </h4>";
                                                              }  ?>
                                                         </div>
                                                         </div>
                                                         <hr>

                                                         <div class= "row"> 
                                                           <div class="col"> 
                                                           <h3>Tenancy Agreement: </h3></div>
                                                           <div class = "col">
                                                             <?php 
                                                             echo "<img src='../contract_images/$contract_image' style= max-width:100%;
                                                             max-height:100%;>";
                                                             ?>
                                                                                                                      </div>
                                                         </div>
                                                         <hr>
                                                         <div class= "row"> 
                                                           <div class="col"> 
                                                           <h3>Street View Image </h3></div>
                                                           <div class = "col">


                                                         <?php
                                                              echo "
                                                              <a href = '$addressURL'>Street View</a>";
                                                                  }
                                                                ?>




                             </div>
          </div>
          <hr>
		  
		  <hr>
                                                         <div class= "row"> 
                                                           <div class="col"> 
                                                           <h3>Accommodation Type</h3></div>
                                                           <div class = "col">


                                                         <?php
														 $accommodation_type = $conn->prepare('SELECT * FROM accommodation_type JOIN accommodation_review_request ON 
																								accommodation_type.accommodation_type_id = accommodation_review_request.type 
																								WHERE accommodation_review_request.request_id = ?');
														$accommodation_type->bind_param('i', $request_id);

														$accommodation_type->execute();

														$type_result = $accommodation_type->get_result();
														
														 while ($row = $type_result->fetch_assoc()) {
																$type_id = $row['accommodation_type_id'];
																$type_description = $row['description'];
                                                              
															  echo "$type_description";
														 }
                                                                ?>




                             </div>
          </div>
          <hr>

<?php
    $accommodation_exists_boolean="";
    $accommodation_exists = $conn->prepare("SELECT * FROM accommodation_review_request WHERE NOT EXISTS 
                                          (SELECT * FROM accommodation WHERE accommodation.housenumber = ?
                                           AND accommodation.postcode = ?)LIMIT 1");
    $accommodation_exists->bind_param('ss', $request_house_number, $request_postcode);

    $accommodation_exists->execute();

    $result = $accommodation_exists->get_result();
    while ($row = $result->fetch_assoc()) {
    $accommodation_exists_boolean = $row['request_id'];
    echo "  <div class= 'row'> 
    <div class='col'>
    <h3 style='color:red;'>Accommodation not in system</h3> </div>
    
    <div class='col'>
    Create new accommodation in form below </div></div>
    <hr>
    ";
    }
    if($accommodation_exists_boolean==""){
      echo "
      <div class= 'row'> 
          <div class='col'>
          <a href = 'email.php?request_id=$request_id'
          <button type='button' class='btn btn-success btn-block form-btn'>Email Tenant Review Form</button> </a> </div> </div> <hr>";
    }else {
      echo "
      <div class= 'row'> 
      <div class='col'>
      <button type='button' class='btn btn-secondary btn-block' disabled> Cannot send email until accommodation is in system </button> </div> </div> <hr>";
    }
    
    
    
?>

    <div class= 'row'> 
    <div class='col'>
    <a href = 'delete_request.php?request_id=<?php echo $request_id?>'>
    <button type="button" class="btn btn-success btn-block form-btn">Delete Request</button></a>
    </div>
    </div>
    </div>
    </div>
                            
          
          


                                                        <!-- Add Accommodation Form -->

      <div class="card"  style="margin-top:25px;">
      <div class = "row" style="margin-bottom:25px; margin-top:25px;">

      <div class = "col">

      <div class="dropdown">
  <button class="btn btn-secondary btn-block dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Add Accommodation to system
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
  <form action="request.php?request_id=<?php echo $request_id ?>" method="post" id="add_accommodation_form" enctype="multipart/form-data">
	
  <div id="error">
	</div>
                                                                  <div class = "container">
    <div class="form-group">House Number:
    <input type="text" class="form-control" placeholder="Housenumber" name="housenumber" id = "housenumber" value= "<?php echo $request_house_number ?>" /> 
    </div>
	
  <div class="form-group" id="locationField"> Postcode and Street Name:
    <input type="text" class="form-control" placeholder="Postcode and address" id="autocomplete"  onFocus="geolocate()" name="postcode" value="<?php echo $request_postcode ?>" />
    </div>



    <div class="form-group">
    <select class = "form-control"placeholder="Estate Agent or Landlord" name="estate_agent" id="estate_agent" onChange="catOnchange();">
      
    <option value="" disabled selected>Select estate agent/ landlord </option>
 
                          <!-- Looping through estate agents, assigned count variable to exclude 'Other' estate agent option (4th row in array) -->
                          <?php
                        
                        $count = 0;
                        $result =  $conn->query ("SELECT * FROM estate_agent");
                                    while($row = $result -> fetch_assoc()) {
                                      if($count!=4){
                                        $estate_agent_id = $row['estate_agent_id'];
                                        $estate_agent_name = $row['estate_agent_name'];
                                        echo "<option value= '$estate_agent_id' id = '$estate_agent_id'>$estate_agent_name</option>";
                                      }
                                        $count++;
                                                                        } ?>
                                                                        
                                                                       
    </select>
   
    </div>
    
    <div class="form-group">
      
    <select class = "form-control" name = "type" id = "type" placeholder="Type">
    <option value="" disabled selected>Select accommodation type</option>
                        <?php
                        $result =  $conn->query ("SELECT * FROM accommodation_type");
                                    while($row = $result -> fetch_assoc()) {
                                        $type_id = $row['accommodation_type_id'];
                                        $type_description = $row['description'];
                                        echo "<option value= '$type_id'>$type_description</option>";
                                              
                                                                        } ?>
                                                                        </select>
	</div>
	
  <div class="form-group">
	<input type="file" placeholder="image" name="image_to_upload" id="image_to_upload" style="display:none;" />
  <label for="image_to_upload"  class="btn btn-outline-primary">Upload Google Street View image</label>

  <input type="hidden" name="current_tenant" id="current_tenant" value="<?php echo $request_current_tenant; ?>"/>

	</div>
	<hr />
	<div class="form-group">
	
  <button type="submit"  class="btn btn-success btn-block form-btn" name="add_accommodation_button" id="btn-submit">Upload Accommodation</button> 
	
  </div>
	</form>
  </div>
 </div> <!--dropdown menu -->
  </div> <!--dropdown button -->
</div><!--col -->

                                                                        <!--Add Estate Agent Form -->

<div class = "col">

      <div class="dropdown">
  <button class="btn btn-secondary btn-block dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Add Landlord/Estate Agent to system
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 
  <form action="request.php?request_id=<?php echo $request_id ?>" method="post" id="add_accommodation_form" enctype="multipart/form-data">
	
  <div id="error">
	</div>
                                                                  <div class = "container">
    <div class="form-group">
    <input type="text" class="form-control" placeholder="Estate Agent/ Landlord" name="estate_agent_name" id = "estate_agent_name" value = "<?php echo $other_estate_agent ?>" />
    </div>
	
	<hr />
  <div class="form-group">
	<input type="email" class="form-control" placeholder="Email address" name="email" id="email" />
	</div>
  
  <hr />
	<div class="form-group">
	<input type="password" class="form-control" placeholder="Password" name="password_1" id="password_1" />
	</div>
  <hr />

  <hr />
	<div class="form-group">
	<input type="password" class="form-control" placeholder="Confirm their Password" name="password_2" id="password_2" />
	</div>
  <hr />

	<div class="form-group">
	
  <button type="submit"  class="btn btn-success btn-block form-btn" name="add_estate_agent_button" id="btn-submit">Upload Estate Agent/ Landlord</button> 
	
  </div>
	</form>
  </div>

 </div> <!--dropdown menu -->
  </div> <!--dropdown button -->
</div><!--col -->

</div><!--row-->



</div> <!--card-->


  </div>

  <script>
// This sample uses the Autocomplete widget to help the user select a
// place, then it retrieves the address components associated with that
// place, and then it populates the form fields with those details.
// This sample requires the Places library. Include the libraries=places
// parameter when you first load the API. For example:
// <script
// src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

var placeSearch, autocomplete;

var componentForm = {
  street_number: 'short_name',
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  country: 'long_name',
  postal_code: 'short_name'
};

function initAutocomplete() {
  // Create the autocomplete object, restricting the search predictions to
  // geographical location types.
  autocomplete = new google.maps.places.Autocomplete(
      document.getElementById('autocomplete'), {types: ['geocode']});

  // Avoid paying for data that you don't need by restricting the set of
  // place fields that are returned to just the address components.
  autocomplete.setFields(['address_component']);

  // When the user selects an address from the drop-down, populate the
  // address fields in the form.
  autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
  // Get the place details from the autocomplete object.
  var place = autocomplete.getPlace();

  for (var component in componentForm) {
    document.getElementById(component).value = '';
    document.getElementById(component).disabled = false;
  }

  // Get each component of the address from the place details,
  // and then fill-in the corresponding field on the form.
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
    }
  }
}

// Bias the autocomplete object to the user's geographical location,
// as supplied by the browser's 'navigator.geolocation' object.
function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      var circle = new google.maps.Circle(
          {center: geolocation, radius: position.coords.accuracy});
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5u8hyGlvg8Zf3EzKYEq80s19qvS6GV0k&libraries=places&callback=initAutocomplete"
        async defer></script>

                                        </body>
                                        </html>

<?php
                                                          // UPLOAD ACCOMMODATION
if (isset($_POST['add_accommodation_button'])) {
    // receive all input values from the form
    //ensure no fields are empty

  if(empty($_POST['housenumber']) || empty($_POST['postcode']) || empty($_POST['type']) || empty($_POST['estate_agent'])
   ){
    echo "<script>
    alert('Answer all questions in Add Accommodation form');
    </script>";
  } elseif($_FILES['image_to_upload']['name'] == "") {
    echo "<script>
    alert('No Street View image was uploaded');
    </script>";
    }

    // Ensure the file uploaded is image
    //https://www.php.net/manual/en/features.file-upload.errors.php

elseif ($_FILES['image_to_upload']['error'] !== UPLOAD_ERR_OK) {
  die("Upload failed with error code " . $_FILES['image_to_upload']['error']);
}


  
  else {
    
  //initialise inputs
  $house_number = mysqli_real_escape_string($conn, $_POST['housenumber']);
  $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
  $estate_agent = mysqli_real_escape_string($conn, $_POST['estate_agent']);
  $type = mysqli_real_escape_string($conn, $_POST['type']);
  $current_tenant = mysqli_real_escape_string($conn, $_POST['current_tenant']);
  $modified = '';
  $token = '';
  $tokenExpire = '';
  
  $info = getimagesize($_FILES['image_to_upload']['tmp_name']);
if ($info === FALSE) {
      echo "<script>
    alert('Not a gif/jpeg/png');
    </script>";
    
}

if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
  die("Not a gif/jpeg/png");
}
  
  //ensuring image name is unique
  $ran = rand(0,100000);
  $upload_img = $_FILES['image_to_upload'] ['name'];
  $upload_img = $ran.$upload_img;
  $img_tmp = $_FILES['image_to_upload'] ['tmp_name'];
  $move = move_uploaded_file($img_tmp, "../accommodation_images/".$upload_img);
  if(!$move){           
    echo "Not uploaded because of error ".$_FILES["image_to_upload"]["error"];       
}
      //CHECKING IF HOUSE IS ALREADY IN SYSTEM

$address_check_query = $conn->prepare("SELECT * FROM accommodation WHERE housenumber=? AND postcode=? LIMIT 1");
echo $conn->error;
$address_check_query->bind_param('ss', $house_number, $postcode);
$address_check_query->execute();
$address_check_query_result = $address_check_query->get_result();

if(mysqli_num_rows($address_check_query_result)>=1){
  echo "<script>
  alert('House already in system');
window.opener.location.reload();</script>";
} else{

$insert_query= $conn->prepare("INSERT INTO accommodation (housenumber, postcode, accommodation_type, accommodation_estate_agent, image, 
                                                          created, modified, current_tenant_id, token, tokenExpire)
                               VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?)");
echo $conn->error;
$insert_query->bind_param("ssiississ", $house_number, $postcode, $type, $estate_agent, $upload_img, $modified, $current_tenant, $token, $tokenExpire);
$insert_query->execute();
$insert_query->close();

 echo "<script>
 alert('Accommodation added!');
  </script>
  <meta http-equiv='refresh' content='0'>";
      
  }
  }
}
?>
                                                                  
<?php
                                                          // UPLOAD ESTATE AGENT
if (isset($_POST['add_estate_agent_button'])) {
    // receive all input values from the form
    //ensure no fields are empty

   if(empty($_POST['estate_agent_name']) || empty($_POST['email']) || empty($_POST['password_1']) ){
    echo "<script>
    alert('Answer all questions in Add Estate Agent form');
    </script>";
   } else {
    
  //initialise inputs
  $new_estate_agent_name = mysqli_real_escape_string($conn, $_POST['estate_agent_name']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password_1 = mysqli_real_escape_string($conn, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($conn, $_POST['password_2']);

  if (empty($password_1)) { array_push($errors, "Password is required"); 
    echo "Password required"; 
  }
  if ($password_1 != $password_2) {
  array_push($errors, "The two passwords do not match");
  echo "<script>
  alert('The two passwords do not match');
  window.opener.location.reload();</script>";
  } else {

  //ensure the password length is at least 6 characters long
  if (strlen($password_1) < 6){ array_push($errors, "Password of 6 characters is required");
    echo "<script>
    alert('Password must have 6 or more characters');
     </script>";
  } else {
 
 $password = password_hash($password_1, PASSWORD_DEFAULT);
  

        //CHECK IF ESTATE AGENT IS ALREADY IN SYSTEM

$estate_agent_check_query = $conn->prepare("SELECT * FROM estate_agent WHERE estate_agent_name=? LIMIT 1");
$estate_agent_check_query->bind_param('s', $new_estate_agent_name);

$estate_agent_check_query->execute();

$new_estate_agent_name_check = $estate_agent_check_query->get_result();
if(mysqli_num_rows($new_estate_agent_name_check)>=1){
// if ($new_estate_agent_name_check >= 1 ) { 
   echo "<script>
      alert('Estate Agent/Landlord already in system');
   window.opener.location.reload();</script>";
 } 
      // first check the database to make sure 
      // a user does not already exist with the same username and/or email
   $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
   $result = mysqli_query($conn, $user_check_query);
   $user = mysqli_fetch_assoc($result);
  
   if ($user) { // if user exists
     if ($user['email'] === $email) {
       array_push($errors, "email already exists"); echo "<script>
                                                           alert('Email aready taken!');
                                                           window.opener.location.reload();</script>";
    }
   }
 
 else{

$insert_query= $conn->prepare("INSERT INTO users (username, email, password, user_type)
                               VALUES (?, ?, ?, 2)");

echo $conn->error;

$insert_query->bind_param("sss", $new_estate_agent_name, $email, $password);

echo $conn->error;


$insert_query->execute();
$insert_query->close();

 echo "<script>
 alert('Eseate Agent added!');
  </script>
  <meta http-equiv='refresh' content='0'>";


  
$insert_query_two= $conn->prepare("INSERT INTO estate_agent (estate_agent_name)
  VALUES (?)");

echo $conn->error;

$insert_query_two->bind_param("s", $new_estate_agent_name);

echo $conn->error;


$insert_query_two->execute();
$insert_query_two->close();

}
  }
}
}
}
?>







          






