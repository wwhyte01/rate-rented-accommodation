<?php
include("../registration/db_connect.php");
function getAllReviewRequests(){
   
    global $conn;
    $result = $conn->query("SELECT * FROM `accommodation_review_request` JOIN estate_agent ON accommodation_review_request.request_estate_agent = estate_agent.estate_agent_id 
                            ORDER BY accommodation_review_request.request_date DESC");
    while($row=$result->fetch_assoc()){
      $request_id = $row['request_id'];
      $request_house_number = $row['request_house_number'];
      $request_postcode = $row['request_postcode'];
      $estate_agent_name = $row['estate_agent_name'];
     

      echo "
      
      <div class='col-sm-6'>
        <div class='card text-center' style ='margin-top:15px;'>
          <div class='card-body'>
            <h5 class='card-title'>$request_house_number $request_postcode</h5>
            <p class='card-text'>Letted by: $estate_agent_name<br>
                                 </p>
                                 
            <a href='request.php?request_id=$request_id' class='btn btn-primary btn-block form-btn' style='background-color:#7047d7;'>See request details</a>
            
          </div>
        </div>
      </div>
      ";
    }
}


function generateNewString($len = 10) {
  $token = "poiuztrewqasdfghjklmnbvcxy1234567890";
  $token = str_shuffle($token);
  $token = substr($token, 0, $len);

  return $token;
}


function redirectToIndexPage() {
  header('Location: ../index.php');
  exit();
} 

?>