<!DOCTYPE html>
<html lang="en">
<head>
<?php
 
 session_start();
 include("admin_functions.php");
 
 
 include_once("../registration/db_connect.php");
 $sql = "SELECT * FROM users WHERE id='".$_SESSION['user_session']."'";
 $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
 $user_row = mysqli_fetch_assoc($resultset);
 
  if($_SESSION['user_session'] != '61' && $user_row['user_type'] != '3'){
      header("Location: ../index.php");
 }


 ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Manage Review Requests</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    

    <link rel="shortcut icon" href = "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" type = "image/x-icon"><!--tab icon -->
</head>
<body>
  <!--NAV BAR-->
         <nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#"><img class="-circle" src= "http://www.clker.com/cliparts/x/u/d/P/V/w/pink-house-hi.png" width="50" height="50"></a>
              
                <div class="collapse navbar-collapse" id="mynav">
                  <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/index.php#">Rate Your Rentable Accommodation<span class="sr-only">(current)</span></a>
                    </li>
                    <?php
                    echo 
                    "<li class='nav-item'>
                              <a class='nav-link' href='http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/registration/login/logout.php#'>Logout</a>
                                    </li>";
                    
                   ?>
                  </ul>
                  <form class="form-inline my-2 my-lg-0" method = "get" action = "../results.php" style = 'width:50%;'>
                    <input class="form-control mr-sm-2" type="search" name ="searchbar_query" placeholder="Search for properties or estate agents" aria-label="Search" style = 'width:75%;'>
                    
                    <button type="submit" name="search">
                        <i class="fas fa-search-location fa-2x"></i>

                    </button>
                  </form>
                </div>
              </nav> 

      <!--NAV BAR FINISH-->


      <div class="col">
      
      <h3 class="main-subheading" style="color:#7047d7;  margin-top:25px;">Latest Requests </h3>
       <hr />
     
   

                  <!--Getting the list of accommodation reviews -->
             <div class='row'>
               <?php

                getAllReviewRequests()


                  ?>

</div>





   </div>



      </body>
</html>