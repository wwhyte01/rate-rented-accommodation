<?php
session_start(); 
use PHPMailer\PHPMailer\PHPMailer;
include("admin_functions.php");
global $conn;

if(isset($_GET['request_id'])) {
    $request_id = $_GET['request_id'];

        

        $get_request_id = $conn->prepare("SELECT * FROM accommodation JOIN accommodation_review_request
                            ON accommodation_review_request.request_house_number = accommodation.housenumber 
                            AND accommodation_review_request.request_postcode = accommodation.postcode 
                            JOIN users ON accommodation_review_request.request_current_tenant = users.id 
                            WHERE accommodation_review_request.request_id = ?");

        $get_request_id ->bind_param('i', $request_id);
        $get_request_id->execute();

        $result = $get_request_id->get_result();

                while($row=$result->fetch_assoc()){
                $request_id = $row['request_id'];
                $request_house_number = $row['request_house_number'];
                $request_postcode = $row['request_postcode'];
                $request_current_tenant_id=$row['request_current_tenant'];

                $current_tenant_id=$row['current_tenant_id'];
                $tenant_username = $row['username'];
                $tenant_email = $row['email'];
                $accommodation_id=$row['accommodation_id'];

                $token = generateNewString();

	        

            // Setting current tenant of accommodation to tenant who requests to review
            $update_current_tenant = "UPDATE accommodation SET current_tenant_id = '$request_current_tenant_id'
                                     WHERE accommodation.accommodation_id = '$accommodation_id'";
            $result_update_current_tenant = $conn->query($update_current_tenant);

            //Setting the token to Accommodation row to be reviewed
            $update_token = "UPDATE accommodation SET token='$token', 
                           tokenExpire=DATE_ADD(NOW(), INTERVAL 1 DAY)
                         WHERE accommodation_id='$accommodation_id'";
            $result_update_token = $conn->query($update_token);


            require_once "PHPMailer/PHPMailer.php";
	        require_once "PHPMailer/Exception.php";

            $mail = new PHPMailer(TRUE);
            
            /* Open the try/catch block. */
try {
    /* Set the mail sender. */
    $mail->setFrom('wwhyte01@qub.ac.uk', 'Rate Your Rentable Accommodation');
 
    /* Add a recipient. */
    $mail->addAddress($tenant_email, $tenant_username);
 
    /* Set the subject. */
    $mail->Subject = "$request_house_number $request_postcode Review Form";
 
    $mail->isHTML(true);

    /* Set the mail message body. */
    $mail->Body = "  Hi, $tenant_username<br><br>
	            
    Below is the review form which is valid for the next 24hours, please click on the link below:<br>
    <a href=' http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/review/review_page.php?accommodation=$accommodation_id&token=$token'>
    http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/review/review_page.php?accommodation=$accommodation_id&token=$token</a>
    <br><br>

    Let me know if the link does not work or you require another link if this one has expired. <br> <br>
    
    Kind Regards,<br>
    William";
 
    /* Finally send the mail. */
    $mail->send();
 }
 catch (Exception $e)
 {
    /* PHPMailer exception. */
    echo $e->errorMessage();
 }
 catch (\Exception $e)
 {
    /* PHP exception (note the backslash to select the global namespace Exception class). */
    echo $e->getMessage();
 }
    
            }
        }

echo " <script>
alert('Email sent successfully!');
window.location.href = 'http://wwhyte01.lampt.eeecs.qub.ac.uk/rent/admin/request.php?request_id=$request_id'
</script>";

?>

